defmodule Assignment2Test do
  use ExUnit.Case
  doctest Assignment2

  test "greets the world" do
    assert Assignment2.hello() == :world
  end
end
